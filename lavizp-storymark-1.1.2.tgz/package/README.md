# storymark

Storybook for Markdown files - a React-based UI with backend adapters for Next.js and Vite.

## Installation

```bash
npm install @lavizp/storymark
```

Peer dependencies required:

```bash
npm install react react-dom react-markdown
```

## Usage

### Next.js

Create a single API route (no catch-all segments needed):

```ts
// app/api/storymark/route.ts
import { createStorymarkHandler } from '@lavizp/storymark/next'

export const GET = createStorymarkHandler({ docsPath: './docs' })
```

Add the UI to a page:

```tsx
// app/admin/docs/page.tsx
import { StorymarkUI } from '@lavizp/storymark/ui'

export default function DocsPage() {
  return <StorymarkUI />
}
```

### Vite

1. Configure the plugin:

```ts
// vite.config.ts
import { defineConfig } from 'vite'
import { storymarkPlugin } from '@lavizp/storymark/vite'

export default defineConfig({
  plugins: [
    storymarkPlugin({ docsPath: './docs' })
  ],
})
```

2. Add the UI to your app:

```tsx
// src/App.tsx
import { StorymarkUI } from '@lavizp/storymark/ui'

function App() {
  return <StorymarkUI />
}
```

## Multiple Folders

Pass an array to `docsPath` to load markdown files from multiple directories:

```ts
// Next.js
export const GET = createStorymarkHandler({
  docsPath: ['./docs', './guides', './faq']
})

// Vite
storymarkPlugin({
  docsPath: ['./docs', './guides', './faq']
})
```

Each file's ID is prefixed with its folder path to avoid collisions:

```ts
// API response:
[
  { id: 'docs/getting-started', title: 'Getting Started', slug: 'docs/getting-started' },
  { id: 'docs/installation', title: 'Installation', slug: 'docs/installation' },
  { id: 'guides/api', title: 'Api', slug: 'guides/api' },
  { id: 'faq/questions', title: 'Questions', slug: 'faq/questions' }
]
```

Fetch a specific file by its full ID using a query parameter:

```ts
// GET /api/storymark?id=docs/getting-started
// GET /api/storymark?id=guides/api
```

## API

### Core (`@lavizp/storymark/core`)

```ts
import { getMarkdownList, getMarkdownFile } from '@lavizp/storymark/core'

const files = getMarkdownList('./docs')
// [{ id: 'getting-started', title: 'Getting Started', slug: 'getting-started' }]

const content = getMarkdownFile('./docs', 'getting-started')
// '# Hello\n\nThis is markdown content.'

// Multiple folders
const allFiles = getMarkdownList(['./docs', './guides'])
const content = getMarkdownFile(['./docs', './guides'], 'guides/api')
```

### UI (`@lavizp/storymark/ui`)

```tsx
import { StorymarkUI } from '@lavizp/storymark/ui'

<StorymarkUI
  apiEndpoint="/api/storymark"
  basePath="/admin/docs"
/>
```

### Next.js (`@lavizp/storymark/next`)

```ts
import { createStorymarkHandler } from '@lavizp/storymark/next'

createStorymarkHandler({
  docsPath: './docs',
  disableInProduction: false,
})

// Multiple folders
createStorymarkHandler({
  docsPath: ['./docs', './guides'],
})
```

### Vite (`@lavizp/storymark/vite`)

```ts
import { storymarkPlugin } from '@lavizp/storymark/vite'

storymarkPlugin({
  docsPath: './docs',
  disableInProduction: false,
})

// Multiple folders
storymarkPlugin({
  docsPath: ['./docs', './guides'],
})
```

## License

MIT